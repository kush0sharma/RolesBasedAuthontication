﻿using System;

namespace DLL
{
    public class Class1
    {
    }
}
