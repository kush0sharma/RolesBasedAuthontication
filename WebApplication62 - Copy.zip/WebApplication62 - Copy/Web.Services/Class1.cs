﻿using System;

namespace Web.Services
{
    public class Class1
    {
    }
}
